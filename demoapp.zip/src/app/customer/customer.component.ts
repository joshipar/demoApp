import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { ChildCounterComponent } from '../child-component-counter';


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements AfterViewInit {
  cname = "Guest"

  @ViewChild('childcountercomponent')
  sample!: ChildCounterComponent;

  
ngAfterViewInit(){
  console.log("ng After View init")
  console.log(this.sample.count) 
}

increment(){
  console.log('increment')
  this.sample.increment()
}

decrement(){
console.log('decrement')
this.sample.decrement()
}

}
