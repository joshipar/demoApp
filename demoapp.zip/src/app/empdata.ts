import { Employee } from "./employee";

export const EMPLOYEES : Employee[] =[
    {id:100, ename:"Parag" },
    {id:101, ename:"Prachi" },
    {id:102, ename:"Manas" },
    {id:103, ename:"Daesha" },
    {id:104, ename:"Niyati" },
    {id:105, ename:"Rahul" },
    {id:106, ename:"Aadesh" },
    {id:107, ename:"Ruchi" },
    {id:108, ename:"Mayuri" },
    {id:108, ename:"Ankita" }
]