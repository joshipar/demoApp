import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  headerTitle:string = ""
  
  img1 = "../../assets/r2.jpg"
  img2 = "../../assets/r1.jpg"
  height = "100"
  width = "300"
  
  constructor() {
    this.headerTitle = "Khana Khajana Restaurant"
   }

  zoomin(size:string){
    this.height=size
    this.width = size
  } 

  zoomout(){
    this.height="100"
    this.width = "300"
  }

  changeheader(title:string,img1:string,img2:string){
    //console.log(title)
    this.headerTitle = title
    this.img1 = "../../assets/"+img1
    this.img2 = "../../assets/"+img2
  }


  ngOnInit(): void {
  }

}
